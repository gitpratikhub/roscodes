#!/usr/bin/env python3

import rospy
from std_msgs.msg import String
import time
import requests
from datetime import datetime
from dateutil.tz import gettz

def switch():
    rospy.init_node('switch_node')
    # switch_publisher = rospy.Publisher('motion_command', String, queue_size=10)
    switch_status_msg = String()
    rate = rospy.Rate(1)

    while not rospy.is_shutdown():
        cloud_response = requests.get('https://pratikmane.000webhostapp.com/ros/read_all.php')
        cloud_json_data = cloud_response.json()        
        START_TIME = int(cloud_json_data['data'][0]['startTime'])      
        END_TIME = int(cloud_json_data['data'][0]['endtime'])     

        CURRENT_TIME = datetime.now(tz=gettz('Asia/Kolkata'))
        if CURRENT_TIME.hour > START_TIME and CURRENT_TIME.hour < END_TIME:
            if rospy.get_param('operationStatus') != 'on':
                switch_status_msg.data = 'on'
                # switch_publisher.publish(switch_msg)
                rospy.loginfo('Controller Switched %s' %switch_status_msg.data)       
                
                rate = rospy.Rate(1)

                rospy.set_param('operationStatus', 'on')
        
        else :
            if rospy.get_param('operationStatus') != 'off':
                rospy.set_param('operationStatus', 'off')
                switch_status_msg.data = 'off'
                
                rospy.loginfo('Controller Switched %s' %switch_status_msg.data)       

                rate = rospy.Rate(5) 
            
            
        rate.sleep()

def setParams(cloud_data):
    if cloud_data['updatedAt'] != rospy.get_param('updatedAt'):
        rospy.set_param('updatedAt', cloud_data['updatedAt'])
        rospy.set_param('startTime', cloud_data['startTime'])
        rospy.set_param('endtime', cloud_data['endtime'])
        rospy.set_param('operationStatus', cloud_data['operationStatus'])


if __name__ == '__main__':
    switch() 
