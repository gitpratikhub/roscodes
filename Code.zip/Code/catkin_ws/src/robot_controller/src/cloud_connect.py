#!/usr/bin/env python3

import rospy
from std_msgs.msg import String
import time
import requests

# response = requests.get('https://pratikmane.000webhostapp.com/api/led/read_all.php')
# print(response.status_code)
# json_data = response.json()
# print(json_data['led'][0]['status'])

def publishSwitchStatus():
    rospy.init_node('switch_node')
    switch_publisher = rospy.Publisher('motion_command', String)
    switch_msg = String()
    rate = rospy.Rate(5)

    while not rospy.is_shutdown():
        cloud_response = requests.get('https://pratikmane.000webhostapp.com/api/led/read_all.php')
        cloud_json_data = cloud_response.json()
        switch_msg.data = cloud_json_data['led'][0]['status']
        rospy.loginfo('Switch State %s' %switch_msg.data)
        switch_publisher.publish(switch_msg)
        if switch_msg.data == 'on':
            rate = rospy.Rate(1)
        
        rate.sleep()

if __name__ == '__main__':
    publishSwitchStatus()