#!/usr/bin/env python3

import rospy
from std_msgs.msg import Int16, String

def listner():
    rospy.init_node('robot_controller_node')
    rospy.Subscriber('data/ultrasonic', Int16, callback_func)
    rospy.Subscriber('motion_command', String, motionControllerCallbackFunc)
    rospy.spin()

# def ultrasonicSensorSubscriber():    
#     ros_subscriber = rospy.Subscriber('data/ultrasonic', Int16, callback_func)
#     rospy.spin()

def callback_func(message):
    if message.data <= 15 and message.data > 8:
        rospy.loginfo('Sensing Obstacle Nearby')
    if message.data <=8:
        rospy.loginfo('Obstacle Confronted -> Diverting course')    

# def motionControllerSubscriber():    
#     ros_subscriber_2 = 
#     rospy.spin()

def motionControllerCallbackFunc(message):
    rospy.loginfo(message.data)

if __name__ == '__main__':    
    
    # ultrasonicSensorSubscriber()
    # motionControllerSubscriber()
    listner()
