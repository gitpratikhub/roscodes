#!/usr/bin/env python3

import rospy
from std_msgs.msg import Bool
import RPi.GPIO as GPIO # Import Raspberry Pi GPIO library
from time import sleep # Import the sleep function from the time module


STEPS = 800
SLEEP_TIME = 0.00125


def stepperControlSub():
    ros_subscriber = rospy.Subscriber('trigger-actuation', Bool, actuateStepper)
    rospy.spin()

def actuateStepper(message):
    GPIO.setwarnings(False) # Ignore warning for now
    GPIO.setmode(GPIO.BOARD) # Use physical pin numbering
    GPIO.setup(7, GPIO.OUT, initial=GPIO.LOW) 
    if message.data :
        GPIO.setup(8, GPIO.OUT, initial=GPIO.HIGH)
        for step in range(0, STEPS):
            GPIO.output(7, GPIO.LOW) 
            GPIO.output(7, GPIO.HIGH) 
            print('Pulse count : ' + str(step))
            sleep(SLEEP_TIME)    
    
        GPIO.setup(8, GPIO.OUT, initial=GPIO.LOW)
        for step in range(0, STEPS):
            GPIO.output(7, GPIO.LOW) 
            GPIO.output(7, GPIO.HIGH) 
            print('Pulse count : ' + str(step))
            sleep(SLEEP_TIME)

    GPIO.cleanup()
    rospy.loginfo(message.data)

if __name__ == '__main__':
    rospy.init_node('stepper_node')
    stepperControlSub()
