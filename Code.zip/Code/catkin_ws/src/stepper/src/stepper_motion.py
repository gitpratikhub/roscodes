import RPi.GPIO as GPIO # Import Raspberry Pi GPIO library
from time import sleep # Import the sleep function from the time module


GPIO.setwarnings(False) # Ignore warning for now
GPIO.setmode(GPIO.BOARD) # Use physical pin numbering
GPIO.setup(7, GPIO.OUT, initial=GPIO.LOW) 


try:
	while(True):
		x = int(input("Enter the number of steps  =>  "))
		
		if x > 0 :
			GPIO.setup(8, GPIO.OUT, initial=GPIO.HIGH)
			count = x
			while (count > 0): 
				GPIO.output(7, GPIO.LOW) 
				GPIO.output(7, GPIO.HIGH) 
				print('pulse count ' + str(count))
				sleep(0.001)
				count -= 1
		
		if x < 0 :
			GPIO.setup(8, GPIO.OUT, initial=GPIO.LOW)
			count = x
			while (count < 0): 
				GPIO.output(7, GPIO.LOW) 
				GPIO.output(7, GPIO.HIGH) 
				print('pulse count ' + str(count))
				sleep(0.001)
				count += 1
	
	GPIO.output(8, GPIO.LOW) 
	GPIO.output(7, GPIO.LOW) 
	GPIO.cleanup()
except:
	GPIO.output(8, GPIO.LOW) 
	GPIO.output(7, GPIO.LOW) 
	GPIO.cleanup()
