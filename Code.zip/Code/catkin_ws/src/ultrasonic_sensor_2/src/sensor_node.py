#!/usr/bin/env python3

import rospy
from std_msgs.msg import Int16
import RPi.GPIO as GPIO
import time


def initSensor():
    GPIO.setmode(GPIO.BOARD)

    TRIG = 16
    ECHO = 18

    GPIO.setup(TRIG,GPIO.OUT)
    GPIO.setup(ECHO,GPIO.IN)

    GPIO.output(TRIG, False)
    rospy.loginfo("Sensor Calibrating..")
    time.sleep(1)


def publisherFunc():
    rospy.init_node('ultrasonic_sensor_node')
    ros_publisher = rospy.Publisher('data/ultrasonic', Int16, queue_size=10)
    rate = rospy.Rate(10)
    distance_data = Int16()

    TRIG = 16
    ECHO = 18
    while not rospy.is_shutdown():
        try:
            while True:
                # set the trig pin high for 10microseconds
                GPIO.output(TRIG, True)
                time.sleep(0.00001)
                GPIO.output(TRIG, False)

                while GPIO.input(ECHO)==0:
                    pulse_start = time.time()

                while GPIO.input(ECHO)==1:
                    pulse_end = time.time()

                pulse_duration = pulse_end - pulse_start

                distance = pulse_duration * 16600

                if distance <= 50:  
                    distance_data.data = int(distance)
                    ros_publisher.publish(distance_data)
                    rospy.loginfo('Obstacle Distance ' + str(distance_data))
                
                rate.sleep()
                

        except KeyboardInterrupt:
            GPIO.cleanup()

        

if __name__ == '__main__':
    initSensor()
    publisherFunc() 
