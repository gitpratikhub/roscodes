
"use strict";

let DigitalRead = require('./DigitalRead.js');
let DigitalChange = require('./DigitalChange.js');

module.exports = {
  DigitalRead: DigitalRead,
  DigitalChange: DigitalChange,
};
